
document.addEventListener('DOMContentLoaded', () =>{
    buscarDados();
});

function buscarDados() {
    fetch('http://localhost:3000/data')
        .then(response => response.json())
        .then(data => {
            const tabelaBody = document.querySelector('tbody');
            tabelaBody.innerHTML = '';

            data.forEach(produto => {
                const linha = document.createElement('tr');

                const dataFormatada = produto.dataValidade ?
                    new Date(produto.dataValidade).toLocaleDateString('pt-BR') :
                    'N/A';

                const valorFormatado = Number(produto.valorProduto).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                const totalFormatado = Number(produto.valorProduto * produto.quantidadeProduto).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

                linha.innerHTML = `  
                    <td>${produto.idProdutos}</td>
                    <td>${produto.nomeProduto}</td>
                    <td>${produto.quantidadeProduto}</td>
                    <td>${valorFormatado}</td>
                    <td>${totalFormatado}</td>
                    <td>${dataFormatada}</td>
                    <td>${produto.fornecedor}</td>
                    <td>${produto.descricaoProduto}</td>
                    <td><img src="${produto.imagemProduto}" alt="${produto.nomeProduto}" class="product-image"></td>
                `;
                tabelaBody.appendChild(linha);
            });
        })
        .catch(error => console.error('Erro ao buscar dados:', error));
}
