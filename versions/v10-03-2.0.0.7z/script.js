let currentPage = 1;
const rowsPerPage = 10;
let totalPages = 1;

function buscarDados(page = 1, rows = rowsPerPage) {
    fetch('http://localhost:3000/data')
        .then(response => response.json())
        .then(data => {
            const totalRecords = data.length;
            totalPages = Math.ceil(totalRecords / rows);

            const start = (page - 1) * rows;
            const end = start + rows;

            const pageData = data.slice(start, end);

            const tabelaBody = document.querySelector('tbody');
            tabelaBody.innerHTML = '';

            pageData.forEach(produto => {
                const linha = document.createElement('tr');

                const dataFormatada = produto.dataValidade ?
                    new Date(produto.dataValidade).toLocaleDateString('pt-BR') :
                    'N/A';

                const valorFormatado = Number(produto.valorProduto).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                const totalFormatado = Number(produto.valorProduto * produto.quantidadeProduto).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

                linha.innerHTML = `  
                    <td>${produto.idProduto}</td>
                    <td>${produto.nomeProduto}</td>
                    <td>${produto.quantidadeProduto}</td>
                    <td>${valorFormatado}</td>
                    <td>${totalFormatado}</td>
                    <td>${dataFormatada}</td>
                    <td>${produto.fornecedor}</td>
                    <td>${produto.descricaoProduto}</td>
                    <td><img src="${produto.imagemProduto}" alt="${produto.nomeProduto}" class="product-image"></td>
                `;
                tabelaBody.appendChild(linha);
            });

            atualizarBotoesPaginacao(page);
        })
        .catch(error => console.error('Erro ao buscar dados:', error));
}

function atualizarBotoesPaginacao(page) {
    const pageNumbers = document.getElementById('pageNumbers');
    pageNumbers.innerHTML = '';

    const maxVisiblePages = 5;
    const halfVisible = Math.floor(maxVisiblePages / 2);

    let startPage = Math.max(1, page - halfVisible);
    let endPage = Math.min(totalPages, page + halfVisible);

    if (page <= halfVisible) {
        endPage = Math.min(totalPages, maxVisiblePages);
    } else if (page + halfVisible >= totalPages) {
        startPage = Math.max(1, totalPages - maxVisiblePages + 1);
    }

    if (startPage > 1) {
        const dots = document.createElement('span');
        dots.innerHTML = '...';
        dots.classList.add('pagination', 'button', 'disabled');
        pageNumbers.appendChild(dots);
    }

    for (let i = startPage; i <= endPage; i++) {
        const button = document.createElement('button');
        button.innerHTML = i;
        button.classList.add('pagination', 'button');

        if (i === page) {
            button.classList.add('active');
        }

        button.addEventListener('click', () => {
            currentPage = i;
            buscarDados(currentPage, rowsPerPage);
            atualizarBotoesPaginacao(currentPage);
        });

        pageNumbers.appendChild(button);
    }

    if (endPage < totalPages) {
        const dots = document.createElement('span');
        dots.innerHTML = '...';
        dots.classList.add('pagination', 'button', 'disabled');
        pageNumbers.appendChild(dots);
    }
}

document.getElementById('firstPage').addEventListener('click', () => {
    currentPage = 1;
    buscarDados(currentPage, rowsPerPage);
});

document.getElementById('prevPage').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage -= 1;
        buscarDados(currentPage, rowsPerPage);
    }
});

document.getElementById('nextPage').addEventListener('click', () => {
    if (currentPage < totalPages) {
        currentPage += 1;
        buscarDados(currentPage, rowsPerPage);
    }
});

document.getElementById('lastPage').addEventListener('click', () => {
    currentPage = totalPages;
    buscarDados(currentPage, rowsPerPage);
});

buscarDados(currentPage, rowsPerPage);
