const express = require('express');
const cors = require('cors');
const mysql = require('mysql');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json())

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mydb'
});

db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao MySQL:', err);
        return;
    }
    console.log('Conectado ao banco de dados MySQL!');
});

app.get('/data', (req, res) => {
    const query = 'SELECT * FROM produtos'
    querryEx(query, res)
});

function querryEx(query, res) {
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).send('Erro ao buscar dados');
            return;
        }
        res.json(results);
    });
}

app.post('/buscar', (req, res) => {
    const { fieldValue, filterValue } = req.body
    let query = 'SELECT * FROM produtos'
    let newFilterValue
    let newFieldValue

    switch(filterValue) {
        case 'Fornecedor':
            newFilterValue = filterValue.toLowerCase()
            break
        case 'Código do produto':
            newFilterValue = 'idProduto'
            break
        case 'Nome':
            newFilterValue = 'nomeProduto'
            break
        default:
            newFilterValue = null
    }

    if(fieldValue.length > 0) {
        query += ' WHERE ?? LIKE ?'
        newFieldValue = !isNaN(Number(fieldValue)) ? fieldValue : `%${fieldValue}%`
    }

    if(newFilterValue) {
        db.query(query, [newFilterValue, newFieldValue], (error, results) => {
            if (error) {
                console.error('Erro na consulta ao banco de dados:', error);
                return res.status(500).json({ error: 'Erro na consulta ao banco de dados' });
            }
            res.json(results);
        })
    } else {
        querryEx(query, res)
    }
})

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
