const express = require('express');
const cors = require('cors');
const mysql = require('mysql');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json())

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mydb'
});

db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao MySQL:', err)
        return
    }
    console.log('Conectado ao banco de dados MySQL!')
});

function querryEx(query, res) {
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).send('Erro ao buscar dados')
            return;
        }
        res.json(results)
    });
}

app.get('/data', (req, res) => {
    const query = 'SELECT * FROM produtos'
    querryEx(query, res)
});

app.post('/buscar', (req, res) => {
    const { fieldValue, filterValue } = req.body
    const regex = /^([<>]=?|==|!=)\s*(-?\d+(\.\d+)?)/

    let query = 'SELECT * FROM produtos'
    let newFilterValue
    let newFieldValue
    let params = []
    let match
    
    switch(filterValue) {
        case 'Fornecedor':
            newFilterValue = filterValue.toLowerCase()
            break
        case 'Código do produto':
            newFilterValue = 'idProduto'
            break
        case 'Nome':
            newFilterValue = 'nomeProduto'
            break
        case 'Quantidade':
            newFilterValue = 'quantidadeProduto'
            break
        case 'Data de validade':
            newFilterValue = 'dataValidade'
            break
        default:
            newFilterValue = null
    }
    
    if(Array.isArray(fieldValue)) {
        if(fieldValue.length === 2) {
            query += ' WHERE ?? BETWEEN ? AND ?'
            params = fieldValue[0] > fieldValue[1] ? [newFilterValue, fieldValue[1], fieldValue[0]] : [newFilterValue, fieldValue[0], fieldValue[1]]
        } else {
            query += ' WHERE ?? IN ('
            params = [newFilterValue]
            fieldValue.forEach((element, index) => {
                query += `?, `
                params.push(element)
            });
            query = query.slice(0, -2)
            query += ')'
        }
    } else {
        match = fieldValue?.match(regex)

        if(fieldValue === null) {
            // nada
        } else if(newFilterValue === 'dataValidade' && fieldValue === 'N/A') {
            query += ' WHERE ?? IS NULL'
            params = [newFilterValue]
        } else if(newFilterValue === 'dataValidade' && match) {
            query += ` WHERE DATEDIFF(??, CURDATE()) ${match[1]} ?`
            newFieldValue = match[2]
            params = [newFilterValue, newFieldValue]
        } else if(newFilterValue === 'quantidadeProduto' && match) {
            query += ` WHERE ?? ${match[1]} ?`
            newFieldValue = match[2]
            params = [newFilterValue, newFieldValue]
        } else if(newFilterValue === 'quantidadeProduto' && !match) {
            query += ' WHERE ?? = ?'
            newFieldValue = fieldValue
            params = [newFilterValue, newFieldValue]
        } else if(fieldValue.length > 0) {
            query += ' WHERE ?? LIKE ?'
            newFieldValue = !isNaN(Number(fieldValue)) ? fieldValue : `%${fieldValue}%`
            params = [newFilterValue, newFieldValue]
        }
    }

    if(newFilterValue) {
        db.query(query, params, (error, results) => {
            if (error) {
                console.error('Erro na consulta ao banco de dados:', error)
                return res.status(500).json({ error: 'Erro na consulta ao banco de dados' })
            }
            res.json(results)
        })
    } else {
        querryEx(query, res)
    }
})

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
